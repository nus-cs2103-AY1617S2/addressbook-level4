#!/bin/bash

set -euo pipefail

python3 --version
